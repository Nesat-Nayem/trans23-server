// const express = require("express");
// const { mailSend } = require("../controllers/mailControllers");


// const router = express.Router();

// // post orders
// router.post("/sendMail", mailSend);


// module.exports = router;

// const express = require("express");
// const { getAmount, postAmount } = require("../controllers/amountControllers");


// hi

// const router = express.Router();

// router.get('/getNotificationdata', getAmount)
// router.post('/postAmountNotify', postAmount)

// module.exports = router;
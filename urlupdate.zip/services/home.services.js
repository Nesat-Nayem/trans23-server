// const HomeRelocate = require("../models/HomeRelocateModels")

// exports.updateHomeRelocateService = async(updateId,data) =>{
    
//     const result = await HomeRelocate.updateOne(
//         {_id:updateId},
//          {$set: data},
//          { runValidators: true }
          
//           );
//     return result;
// }
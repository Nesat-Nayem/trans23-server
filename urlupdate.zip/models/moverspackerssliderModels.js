const mongoose = require('mongoose');
const {Schema} = mongoose;

const moverspackerssliderSchema = new Schema({

})

const MoversSlider = mongoose.model('MoversSlider',moverspackerssliderSchema )

module.exports = MoversSlider;
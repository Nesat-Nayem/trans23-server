// const express = require("express");

// const sendtext = require("../controllers/textcontroller");

// const router = express.Router();

// router.post("/sendsms", sendtext);

// module.exports = router;
